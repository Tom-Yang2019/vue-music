<template>
  <div class="signed">
    <div class="head">
      <span class="back"></span>
      <span class="title">乐签</span>
      <span class="share"></span>  
    </div> 
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="scss" scoped>
  
</style>