import Vue from 'vue'

const eb = new Vue()

export default eb